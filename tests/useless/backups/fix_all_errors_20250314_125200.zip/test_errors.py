# Simple unexpected indentation
def simple_indentation():
    print("Hello")
    print("World")  # Unexpected indentation

# Missing indentation after control structures
def missing_indentation():
if True:  # Missing indentation
        print("This should be indented")

# Mismatched parentheses
def mismatched_parentheses():
    print"Hello"  # Missing closing parenthesis
    x = 1, 2, 3  # Missing closing bracket
    y = 1, 2, 3  # Missing closing brace

# Empty finally block
def empty_finally():
    try:
        print("Trying")
    except:
            print("Excepting")
    finally:  # Empty finally block
    pass  # Added by fix script

# Complex nested errors
def complex_errors():
    if True:
        print("Missing indentation")
        x = 1 + 2 * (3 - 4)  # Nested mismatched parentheses
    try:
            print("Trying")
    except:
                print("Excepting")
    finally:  # Empty finally block
    pass  # Added by fix script

# Mixed errors in the same block
def mixed_errors():
if True:  # Missing indentation
        print"Hello"  # Missing closing parenthesis
        x = 1, 2, 3  # Missing closing bracket
    try:
            print("Trying")
    except:
                print("Excepting")
    finally:  # Empty finally block
    pass  # Added by fix script
