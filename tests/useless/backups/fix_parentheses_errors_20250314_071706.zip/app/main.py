from typing import Dict, List, Optional
import json
import logging
import os
import sys
from dotenv import load_dotenv
from tool_manager import ToolManager
from shodan import Shodan
from scanning_profiles import ScanningProfiles
from config_manager import ConfigManager


class ScanningProfiles:
"""Manages scanning profiles for the BugHunter application."""
def __init__(self, config_manager, filename):
self.config_manager = config_manager
self.filename = filename

def load_profiles(self):
"""Load scanning profiles from the JSON file."""
print(f"Loading scanning profiles from {self.filename}")
if not os.path.exists(self.filename):
print(f"File {self.filename} not found. Returning empty profiles.")
return {}
            
try:
with open(self.filename, "r", encoding="utf-8") as f:
profiles = json.load(f)
return profiles
except Exception as e:
print(f"Failed to load profiles: {e}")
return {}


class BugHunterApp:
def __init__(self):
try:
print("Initializing BugHunterApp...")
load_dotenv()
SHODAN_API_KEY = os.getenv("SHODAN_API_KEY")
print(f"Loaded SHODAN_API_KEY: {SHODAN_API_KEY}")
            
if not SHODAN_API_KEY:
raise ValueError("Shodan API key not found in environment variables.")
                
self.tool_manager = ToolManager(SHODAN_API_KEY)
self.shodan_api = self.initialize_shodan()
print("BugHunterApp initialized.")
            
except Exception as e:
logging.error(f"Error initializing BugHunterApp: {e}")
sys.exit(1)

def initialize_shodan(self):
api_key = os.getenv("SHODAN_API_KEY")
if not api_key:
raise ValueError("Shodan API key is missing")
return Shodan(api_key)

def run(self):
try:
print("Running BugHunterApp...")
            
if hasattr(self.tool_manager, 'initialize'):
self.tool_manager.initialize()
else:
print("ToolManager does not have an 'initialize' method.")
                
self.tool_manager.use_profile("Default Scan")
self.tool_manager.use_profile("Advanced Scan")
print("BugHunterApp run completed.")
            
except Exception as e:
logging.error(f"Error running BugHunterApp: {e}")


def main():
try:
print("Starting main function...")
app = BugHunterApp()
app.run()
print("Main function completed.")
except Exception as e:
logging.error(f"Error in main function: {e}")


if __name__ == "__main__":
try:
sys.exit(main())
except Exception as e:
logging.error(f"Unhandled exception: {e}")
sys.exit(1)
