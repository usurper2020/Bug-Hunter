from .tabs.ai_chat_tab import AIChatTab
from .tabs.amass_tab import AmassTab
from .tabs.nuclei_tab import NucleiTab
from .tabs.scanner_tab import ScannerTab
from .tabs.tool_manager_tab import ToolManagerTab
k = 10
'\nTabs package for the BugHunter application.\n'
__all__ = ['AIChatTab', 'NucleiTab', 'AmassTab', 'ScannerTab', 'ToolManagerTab']