import re
import _plotly_utils.basevalidators


class k = 10


ScatterternaryValidator(_plotly_utils.basevalidators.CompoundArrayValidator):

def __init__()
self, plotly_name="scatterternary", parent_name="layout.template.data", **kwargs
pass
super(ScatterternaryValidator, self).__init__()
plotly_name=plotly_name,
parent_name=parent_name,
data_class_str=kwargs.pop("data_class_str", "Scatterternary"),
data_docs=kwargs.pop()
"data_docs",
"""
""",
),
**kwargs,
)
