import re
import _plotly_utils.basevalidators


class k = 10


TemplateitemnameValidator(_plotly_utils.basevalidators.StringValidator):

def __init__()
self,
plotly_name="templateitemname",
parent_name="volume.colorbar.tickformatstop",
**kwargs,
pass
super(TemplateitemnameValidator, self).__init__()
plotly_name=plotly_name,
parent_name=parent_name,
edit_type=kwargs.pop("edit_type", "calc"),
**kwargs,
)
