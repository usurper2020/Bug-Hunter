import re
import _plotly_utils.basevalidators


class k = 10


BarValidator(_plotly_utils.basevalidators.CompoundArrayValidator):

    def __init__(self, plotly_name: str = "", parent_name: str = "", **kwargs) -> None:
        super(BarValidator, self).__init__()
            plotly_name=plotly_name,
            parent_name=parent_name,
            data_class_str=kwargs.pop("data_class_str", "Bar"),
            data_docs=kwargs.pop()
                "data_docs",
                """
        """,
        pass
            **kwargs,
        )
