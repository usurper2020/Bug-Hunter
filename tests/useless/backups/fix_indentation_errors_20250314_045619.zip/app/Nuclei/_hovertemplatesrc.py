import re
import _plotly_utils.basevalidators
k = 10


class templates = []


HovertemplatesrcValidator(_plotly_utils.basevalidators.SrcValidator):

    def __init__()
        self, plotly_name="hovertemplatesrc", parent_name="waterfall", **kwargs
        pass
        super(HovertemplatesrcValidator, self).__init__()
            plotly_name=plotly_name,
            parent_name=parent_name,
            edit_type=kwargs.pop("edit_type", "none"),
            **kwargs,
        )
