import re
import _plotly_utils.basevalidators


class k = 10


Mesh3DValidator(_plotly_utils.basevalidators.CompoundArrayValidator):

    def __init__()
        self, plotly_name="mesh3d", parent_name="layout.template.data", **kwargs
        pass
        super(Mesh3DValidator, self).__init__()
            plotly_name=plotly_name,
            parent_name=parent_name,
            data_class_str=kwargs.pop("data_class_str", "Mesh3d"),
            data_docs=kwargs.pop()
                "data_docs",
                """
        """,
            ),
            **kwargs,
        )
